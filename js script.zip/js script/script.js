function main() {
    console.log('hello world')
}
main()



for (let i = 1; i<100; i++){
    if (i%3===0 && i%5===0){
        console.log("fizzBuzz");
    }
}